
import React, { useState } from "react";
import axios from "axios";
import "./Weather.css";

const Weather = () => {
  const [city, setCity] = useState(""); // for city name input
  const [weatherData, setWeatherData] = useState(null); // to store weather data
  const [error, setError] = useState(""); // for error messages

  const API_KEY = "1fc2666fe7db88edb709f690f821b295"; 
  const API_URL = "https://api.openweathermap.org/data/2.5/weather";

  const getWeatherData = async () => {
    if (!city) {
      setError("Please enter a city");
      return;
    }

    setError(""); // Clear previous errors

    try {
      const response = await axios.get(API_URL, {
        params: {
          q: city,
          appid: API_KEY,
          units: "metric", // Change to "imperial" for Fahrenheit
        },
      });

      setWeatherData(response.data); // Store weather data
    } catch (err) {
      setError("City not found!"); // Handle errors
      setWeatherData(null);
    }
  };

  return (
    <div className="weather-container">
      <h1>Weather App</h1>
      <input
        type="text"
        placeholder="Enter city"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        className="city-input"
      />
      <button onClick={getWeatherData} className="submit-btn">
        Get Weather
      </button>

      {error && <div className="error">{error}</div>}

      {weatherData && (
        <div className="weather-info">
          <h2>{weatherData.name}, {weatherData.sys.country}</h2>
          <p>{weatherData.weather[0].description}</p>
          <p>Temperature: {weatherData.main.temp}°C</p>
          <p>Humidity: {weatherData.main.humidity}%</p>
          <p>Wind Speed: {weatherData.wind.speed} m/s</p>
        </div>
      )}
    </div>
  );
};

export default Weather;

